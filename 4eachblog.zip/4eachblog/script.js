//$('#mainvisual img:gt(0)').hide();
//setInterval(function() {
//    $('#mainvisual :first-child').fadeOut().next('img').fadeIn().end().appendTo('#mainvisual');
//}, 4500);